# Understanding experiments — the log

One row per experiment. The loop (owner, 2026-09-29):
cause found → patch → regression → merge → frozen score → next cause.
Work time is the time the chat or the plan manager was changing or measuring.
Wait time is the time a finished patch sat before the next step (a permission
prompt, a merge, a score). Times are local, from commit and run timestamps.

| # | Structural cause | Patch (commit) | Work | Wait | Regression | Frozen exam | Remaining largest causes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | baseline, main 2145028 | — | — | — | — | 63/108, 0 wrong, 0 violations | question itself unread 22; earlier statement unread 15; other 8 |
| 1 | (from dev v6, statements) a holding recorded under a key that kept a case particle, so the later transfer finds no count | 15e4810, merged db7cb9f | chat 18 min; plan manager 10 min (merge, exam, suite) | chat 13 min on runs; 0 on prompts; patch reported 14:01, merged 14:02, scored 14:05 | suite 2254 passed, the 3 known failures; seven-step 7/7 both languages; dev v6 check 109 → 121/234 at effort 3 | **63/108, 0 turns changed**, 0 wrong, 0 violations (`dialogue-gate-2026-09-22/experiment-01.json`); the ranking fired on 0 exam turns | see below |

## What experiment 1 showed

The cause was found on the dev set and the exam does not have it. From experiment
2 on, the cause is found on the exam's own failures, by structure and counts only
(the plan manager's profile; no sentence leaves the exam), and the chats patch that.

Exam profile at db7cb9f, the 45 held answerable turns:

| Structural cause | Held answerable turns | Evidence (counts) |
| --- | --- | --- |
| A follow-up of 1 to 3 words inherits a question frame only right after an answered count question | 13 | previous turn: a held question 5, a clarify exchange 8, a why 2; almost all name a new holder |
| A statement that does not name its thing | about 15 (behind 9 statements) | 12 statements unrecorded; holder named in 12; thing not named in 9; count as a word in 12, as digits in 0; 5 English transfers refused as missing_initial_quantity |
| Other unread questions | 9 | 4 count questions over 3 words; 2 totals of several holders; 2 without a count word; 1 comparison |
| Cross-language question | 4 | no_referent / cross_language_unmatched |
| Other | 4 | unresolved 2, repair_protected 1, not_stated 1 |

Experiment 2 (statements chat): the unnamed thing as a candidate from the
conversation. Experiment 3 (questions chat): the question frame kept when the
question is read, so a follow-up inherits it whatever became of the question.

## Experiments 2 and 3

| # | Structural cause | Patch (commit) | Work | Wait | Regression | Frozen exam | Note |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | (exam) a short follow-up inherits a question frame only right after an answered count question; the question reader accepts forms one by one | 4d77126, merged fd73709 | chat 35 min; plan manager 12 min | chat 15 min on runs; reported 14:19, merged 14:19, scored 14:22 | **7 new failures** (suite 2,248 passed, 10 failed): round-2 safety test of a scope word over one holder ×3, a probe word declared, a grid sentence shared with dev4, a learning-flow test, the chat's own effort-3 pin inside the parallel run. Merged before the suite had run: from now on the chat runs the full suite before it reports | **69/108** (+6), 0 wrong, 0 violations; questions unread 22 → 8; held behind something unread 15 → 22; one missing-premise turn right → held (`experiment-02.json`); composition 340/340; reasoning 110/113, 0 wrong | grid en 115/299 → 293/314, ko 173/357 → 343/375; dev v6 check 109 → 151/234 |
| 3 | (exam) a statement that does not name its thing | 5ae1b22, merged 24feb64 | chat 11 min; plan manager 6 min | chat 12 min on runs; reported 14:28, merged 14:41 (13 min behind the suite re-run), scored 14:43 | same 10 as experiment 2, none new | **69/108, gate unchanged**; missing premise 3 → 5 of 20, ambiguous 7 → 8 of 12 (`experiment-03.json`) | the patch covers "nothing after the number"; the exam's form has a word after the number |

Exam profile at 24feb64, the 39 held answerable turns: held behind something
unread 22 (13 behind the 12 unrecorded statements, 6 behind a correction turn
that is not read, 3 other); question not read 8; cross-language 4;
which_referent 2, unresolved 2, not_stated 1.

Masked shapes of the unrecorded English transfers (names, things and numbers as
placeholders, every other word as `w`): `GIVER w RECEIVER NUMWORD w .` (2),
`GIVER w NUMWORD w w RECEIVER .` (1), and the same with a title written with a
period before each name (2). The slot after the number holds a word that is not
the thing.

Next: the seven regressions (questions chat, first); the slot after the number
as candidates (statements chat); correction turns the reader does not read
(questions chat, after the regressions).

## Diagnosis of the grounding path (owner's request, 2026-09-29, main 24feb64)

No code changed. Every exam turn was played with the reader's output, the
conversation's state just before the turn, the candidate steps run and the hold
reason recorded; structure and counts only.

**The conversation's state (the overlay) works.** Of 210 gold facts a turn needed
where every earlier statement had been read, 205 were in the state with the right
value; the other 5 had the holder counted, not with that thing. 0 uses of
withdrawn evidence. The state is a list of the sentences said, replayed into facts
keyed by words (holder words + thing); there is no canonical identity. 25 matching
keys keep 1 to 3 extra words and 7 facts have several keys, and that is the root
of only 2 failures.

**The break is the reader → grounding bridge.** 84 exam turns are not right:

| Class | Turns | Of the 39 held answerable |
| --- | --- | --- |
| reader_did_not_emit_partial_candidate (the reader returns nothing; no candidate is built; the state is never asked) | 36 | 11 |
| grounding_candidate_not_built (a complete reading with a wrong word in the thing slot; the state refuses it; no other candidate) | 5 | 0 |
| overlay_lookup_failure | 7 | 2 |
| identity_resolution_failure | 2 | 1 |
| other: a tie held where the exam expects one answer | 2 | 2 |
| overlay_write_failure | 0 | 0 |
| state_validation_rejected_correct_candidate | 0 | 0 |
| cascade, held behind one of the above | 32 | 23 |

The 23 cascaded answerable turns wait on: a statement with no candidate built 9,
a statement the reader returned nothing for 4, a correction the reader returned
nothing for 6, a lookup failure 2, an identity failure 1, unexplained 1. So the
bridge accounts for 30 of the 39, lookup 4, identity 2, ties 2, unexplained 1.
In all 11 unread answerable questions the state already held every needed fact.

Smallest code paths: `marco/reasoning/context.py` `_read_unsaid_thing` (the test
that skips a subject that already carries a thing), and `_turn` where a reading of
None goes to `_check_readings` and then to the unread store, with
`RelationalParser.parse(partial=True)` returning None instead of what it did
recognise. Experiment 3's patch was reached on the 5 statements and returned None
on each: it fixed a symptom the exam does not have.

## Experiment 4: the regressions of experiment 2

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 4 | the question patch read a scope word over one holder as a modifier, declared a probe word, put a dev4 sentence in the grid, let a follow-up name nothing of the conversation, and its pin test depended on other tests' writes | c226d02, merged 16bf9f2 | chat 40 min; plan manager 10 min | chat 12 min on runs; reported about 14:57, merged 14:58, exam scored 15:01; **the suite took 52 min instead of 6** and the composition and reasoning gates an hour, because two chats and the plan manager ran tests on one machine (load average 10 to 15) | suite 2,270 passed, the 3 known failures; gate test files 35 passed | **67/108** (−2: two Korean turns back to held, the cost of the restored safety hold), 0 wrong, 0 violations; composition 340/340; reasoning 110/113, 0 wrong (`experiment-04.json` in both folders) |

Owner's decision after the diagnosis (2026-09-29): the statements chat adds the
wrong-thing candidate; the questions chat returns the recognised structure as a
partial candidate instead of None.

## Experiment 5: the wrong-thing candidate (with the Korean holding that names no thing)

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 5 | (exam, diagnosed) a statement read completely with a word in the thing slot that is not the thing; the state refuses it and no other candidate is built | aed3587 with 08826d5, merged c37e4d6 | chat 35 min; plan manager 8 min | chat 85 min, of which its full suite 63 min at load average about 60; reported 17:00, merged 17:01, scored 17:03 | suite 2,312 passed, the 3 known failures, 344 s run alone | gate **67/108** unchanged, 0 wrong, 0 violations; **statements recorded 138 → 142 of 150**; refused as invalid 5 → 2; ambiguous 8 → 7 of 12 (`experiment-05.json`) |

The four statements are recorded and the questions after them stay held: the
question reader returns nothing for them, or they wait on a correction or a
which-person turn. The two transfers still refused are the two cases the patch
excludes on purpose (the amount "one" before a word without a plural form; a
plural word that is not the thing): taking out a thing that was said would
answer about another thing.

## Experiment 6: the one wrong record

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 6 | (exam) a transfer recorded with a stale count: the safety check that holds a holder behind an unread statement asked for every word of the holder's key, and an unread use-up that leaves the thing to a pronoun has no thing word | f347d4d, merged 27f2656 | chat 10 min; plan manager 5 min | chat 8 min on runs; reported 17:18, merged 17:19, scored 17:22 | chat's full suite 2,284 passed, 1 known failure (gate files left out), 6 min; gate files and both round-7 test files run at merge: passed | gate 67/108 unchanged; **wrong records 1 → 0: no wrong turn is left on the exam**; statements 142 right, 8 held (`experiment-06.json`) |

## Experiment 7: the partial reading as a candidate

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 7 | (exam, diagnosed) the reader returns nothing for a sentence it cannot read whole, so no candidate is built and the conversation's state is never asked | 6baadc8 with e3c3194 and ce36dd0, merged a3e0490 | chat 75 min; plan manager 6 min | chat 45 min (machine load 25 to 52 from other runs); reported 17:35, merged 17:36, scored 17:39 | chat's full suite 2,292 passed, 1 known failure (gate files left out); gate files, round-2 and round-7 tests at merge: 258 passed | **76/108 (70.4%)**, +9, 0 wrong on the whole exam, 0 violations; English 41 of 54, Korean 35 of 54; corrections 12 → 14 of 18; why 18 → 19 of 26 (`experiment-07.json`) |

Exam profile at a3e0490, the 32 held answerable turns: the reader returns nothing
and the grounding builds no candidate 11 (in 10 the state holds every needed
fact); held behind an unread turn 17 (behind a statement the reader returns
nothing for 4, behind a correction 4, behind the two transfers the wrong-thing
candidate excludes on purpose 4, behind a lookup failure 3, other 2); lookup
failure 2; identity 1; a tie held where the exam expects one answer 1.

## Experiment 8: the short follow-up, the comparison, the near key

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 8 | (exam) the grounding builds no candidate for a very short turn that names a holder or thing of the state beside a word that says nothing, for a comparison of two named holders, and for a count asked under a key the state lacks | 004ef0a with 098e620, merged 7894c11 | chat 75 min; plan manager 5 min | chat 20 min on runs; reported 18:13, merged 18:14, scored 18:17 | chat's full suite 2,303 passed, 1 known failure (gate files left out); gate files and the round-2, round-6 and round-7 reading tests at merge: 381 passed. One pin of round 6 changed: a held question is now answered with the expected value | **81/108 (75.0%)**, +5, 0 wrong on the whole exam, 0 violations; English 44 of 54, Korean 37 of 54 (`experiment-08.json`) |

Exam profile at 7894c11, the 27 held answerable turns: 19 wait behind a root turn
(two English transfers the wrong-thing candidate excludes 4; three which-person
turns held as not stated or without a referent 5; two corrections the reader
returns nothing for 4; three Korean statements 5; the English use-up with a
pronoun 1); question not read 5; lookup 2; tie 1.

## Experiments 9 and 10

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 9 | (exam, then diagnosed on invented sentences) a use-up is not read when a trailing phrase says what the things went to; the pronoun was not the blocker | a0acf71 with 0989dcc, merged b0a7125 | chat 35 min; plan manager 12 min | chat 33 min on runs; reported 18:27, merged 18:28, scored 18:34 | full suite on the merged tree 2,354 passed, the 3 known failures, 397 s; the chat's own suite had caught a dropped negation before its report | **82/108** (+1), statements 142 → 144 of 150, why 19 → 20 of 26, 0 wrong, 0 violations (`experiment-09.json`); dev v6 check 149 → 177/234 |
| 10 | (invented reproduction of the exam's which-person turns) a question whose holder words describe several holders is held instead of asked, and the reply after it is held behind itself | 8ac7cb8, merged 0f00af4 | chat 15 min; plan manager 8 min | chat 15 min on runs; reported 18:38, merged 18:41 after the suite of experiment 9, scored 18:46 | chat's full suite on the merged tree 2,323 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 401 passed | **82/108, no turn changed its bucket**: the invented forms are not the exam's (`experiment-10.json`) |

The exam's which-person turns by masked shape: 12 turns, two candidates each, 5
held. None names a candidate; ten do not name the thing; nine have a pronoun and
three describe the person in other words. The held ones are held as `not_stated`
(English, a description without a pronoun) or `no_referent` (a pronoun). The turn
after is the person's reply, a candidate's name alone or with one or two words,
and it is held when the question before it was held.

## Experiment 11

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 11 | (guessed from the token kinds of the exam's corrections) "the one" read as the amount 1; a correction of two sentences refused; the swap of giver and receiver | 468c8d9, merged 13fbf3d | chat 30 min; plan manager 8 min | chat 15 min on runs; reported 18:57, merged 18:58, scored 19:03 | chat's full suite on the merged tree 2,328 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 406 passed | **82/108, no turn changed its bucket** (`experiment-11.json`) |

Two patches in a row were built from invented sentences and changed no exam turn.
From experiment 12 on the chats get, for each failing exam turn, the trace of the
steps that ran and what each returned, with the token kinds of the partial
reading: the place where the exam turn gives up, not a guess at its words.

## Experiment 12: which-person turns, from the exam's own trace

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 12 | (exam trace) the five held which-person turns are read as a query and end at the pointer resolution (no referent) or at the lookup (not stated); the ask naming the candidates was never reached | 44c9c3c, 4d0fc48, 70ef2c0, merged 8155e2d | chat 20 min; plan manager 8 min | chat 25 min on runs; reported 19:50, merged 19:51, scored 19:55 | chat's full suite on the merged tree 2,333 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 522 passed | **85/108 (78.7%)**, +3; which-person turns 7 → 12 of 12; Korean 39 of 54, English 46 of 54; 0 wrong, 0 violations (`experiment-12.json`). The chat named the turns it expected to move: the five which-person turns and the replies after them. All five moved, and three replies |

Exam profile at 8155e2d, the 23 held answerable turns: 13 read and held behind an
earlier unread turn (six unrecorded statements and four held corrections are the
roots); 10 fail on their own: a total of two holders and a comparison, neither
read (2); very short Korean turns not read or tied (4); read as a query and held
at the lookup (3); one held as a protected repair.

## Experiment 13: the Korean lookup, from masked keys

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 13 | (exam, masked keys) four Korean questions are read and held at the lookup while the state holds the fact: the holder asked alone, the holder with 는 left on, the holder before a word that is no thing of the state | 07f52c6 with 9bb0717, merged f151934 | chat 25 min; plan manager 9 min | chat 20 min on runs; reported 20:19, merged 20:20, scored 20:26 | chat's full suite 2,339 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 547 passed | **86/108 (79.6%)**, net +1: Korean 39 → 41 of 54, **English 46 → 45**; one English which-person turn and the reply after it went from right to held (which-person 12 → 11 of 12); 0 wrong, 0 violations (`experiment-13.json`). The chat expected turns 1, 4 and 10 of its list to move and 2, 3 only if their word is declared: two moved |

The regressed which-person turn ends again at the lookup (`_ground_lookup` then
hold/not_stated) and the reply after it is not read; sent back to the chat as the
first thing to fix.

## Experiment 14: holders given as a number, and the regression of experiment 13

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 14 | (exam trace) a total and a comparison whose holders are given as a number are not read; and the words that stand for the thing had been declared as modifiers, so a pointer lost its second word | dd16cc6 with 720b844, merged b95cad7 | chat 15 min; plan manager 15 min | chat 15 min on runs; reported 20:52, merged 20:53, scored 20:59 | chat's full suite 2,345 passed, 1 known failure (gate files left out). **Gate test F1.3 failed at merge**: one sentence of the chat's grid and test was word for word a sentence of the frozen set. Reworded by the plan manager (21460d8); gate files then 35 passed | **88/108 (81.5%)**, +2; Korean 42 of 54, English 46 of 54; which-person 12 of 12 again; 0 wrong, 0 violations (`experiment-14.json`) |

**What the overlap means.** The chat never saw the exam. It wrote that sentence
from the token kinds of a failing turn, and the kinds were enough to arrive at the
exam's own words. The traces make the patches hit, and they also let the
development fit the exam turn by turn. The score of the frozen 52 is from now on
a development score; the fresh exam placed under the release is the one that
says whether the understanding is general. The plan manager's scripts also showed
the plan manager that one sentence when the overlap was listed.

## Experiment 15, and the audit the owner asked for

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 15 | (chat's own finding) a correction at effort 2 and above could change the statement that carried the NEW amount, backwards; (exam trace) corrections whose corrected statement was kept unread; a counter inside the thing's name taken for a scope word | f00871e with 1afce37, merged 4775494 | chat 20 min; plan manager 12 min | chat 15 min on runs; reported 21:25, merged 21:33 after the effort runs, scored 21:38 | chat's full suite 2,352 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 560 passed | **92/108 (85.2%)**, +4, English 48 of 54, Korean 44 of 54, 0 wrong among the answerable, 0 violations; **one correction is scored wrong (`new_event_added`)**: a statement kept unread was said again with the corrected amount and recorded as a new event (`experiment-15.json`). Not pushed; sent back to the chat |

**Audit at a4a711e (owner's question: hard-coded? graph-based? MARCO's identity?).**
The exam at each effort level: 63, 66, 87, 88 of 108, with no wrong turn at any
level; composition 340 of 340. Level 0 is main before round 7, so 21 of the 25
turns gained come from the candidate search of level 2, not from rules. The
Python added in round 7 (1,906 lines; declarations 313) holds no word list; one
default word ("or") is written in code. No import of a model was added. What is
not as designed: the conversation's state is a list of the sentences said,
replayed into facts keyed by words; the grounding matches the words of those keys
and consults no graph; there is no canonical identity for a holder or a thing.

## Experiment 16: the wrong correction becomes a hold

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 16 | experiment 15 re-said a statement kept unread with the corrected amount and recorded it as a new event | f67e1ef, merged 2267e99 | chat 15 min; plan manager 8 min | chat 10 min on runs; reported 21:59, merged 22:00, scored 22:05 | chat's full suite 2,352 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 560 passed | **90/108 (83.3%)**: the correction is held, not wrong, and the two English questions that rested on it are held again; Korean 44 of 54, English 46 of 54; **0 wrong on the whole exam**, 0 violations (`experiment-16.json`) |

## Experiment 17, and the size of an identity change

| # | Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- | --- |
| 17 | a one-word follow-up named only by a statement kept unread ties between holder and thing | a311ed1, merged dd016c8 | chat 10 min; plan manager 8 min | chat 10 min on runs; reported 22:19, merged 22:20, scored 22:25 | chat's full suite 2,353 passed, 1 known failure (gate files left out); gate files and reading tests at merge: 561 passed | **90/108, no turn changed**: the exam's tie turn is still asked (`experiment-17.json`) |

**Where a holder or a thing is compared by the words of a key** (the questions
chat's read-only count at a311ed1, a lower bound): 119 lines in 44 functions of
`marco/reasoning/context.py`, and 9 more places in `relational_semantics.py` and
`marco/reasoning/inference.py`, where the keys are made by joining name words and
resolved by their leading word. By kind: splitting a key into holder and thing
(`_holder_keys` and every helper built on it); matching a said word to a key;
pointers and salience by leading word or ending; corrections and re-keying;
the statement-side candidates. About a third of the places were written in round
7. The first two kinds would become one lookup by identity; the pointer and
correction kinds carry behaviour pinned by the tests of rounds 2 and 3.

## Identity graph, step 1 (2026-09-30)

| Step | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| 1, the conversation graph: nodes for holders, things and places, alias edges with their turn, count edges with origin (said / computed) and evidence turns, frames as node ids; snapshot v10; the trace names the nodes read; nothing reads the graph yet | 0f1fd7c, merged 396efac | chat 70 min; plan manager 8 min | chat 20 min on runs; reported 12:40, merged 12:42, scored 12:47 | chat's full suite 2,359 passed, 1 known failure, 3 expected failures (gate files left out; the new strict xfail is the two-things-one-holder case); gate files, graph, corrections, round-7 and seven-step tests at merge: 130 passed, 1 xfailed | **90/108, 0 turns changed, 0 reply texts changed**, 0 wrong, 0 violations (`graph-step-1.json`) |

## Identity graph, step 2

| Step | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| 2, the reader's partial candidates grounded to nodes: `_ground_question`, `_which_person`, `_ground_pair`, `_named_reply`, `_partial_frame`, `_record_frame` take nodes and count edges; their local holder helpers are gone; one helper `_graph_nodes` | 3e366d8, merged e35028d | chat 30 min; plan manager 8 min | chat 25 min on runs; reported 13:09, merged 13:11, scored 13:16 | chat's full suite 2,359 passed, 1 known failure, 3 expected failures (gate files left out); gate files, graph, round-2, round-3, round-7 and seven-step tests at merge: 455 passed, 1 xfailed; no re-pin | **90/108, 0 turns changed, 0 reply texts changed**, 0 wrong, 0 violations (`graph-step-2.json`); 1.0 → 1.2 ms per turn at effort 3 |

## Identity graph, step 3, statements 1

| Step | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| 3 (statements 1): the reader names each fact's holder and thing (`fact["parts"]`), the graph splits no string; a receiver named with a relation word is one node (a wrong answer on main gone, 24 not 23); a list of two things of one holder is one holder (the strict xfail passes) | 6d6129a, merged c545af7 | chat about 60 min; plan manager 10 min | reported 13:15, merged 13:17, scored 13:22 | chat: dev v3–v6 check halves at effort 0 and 3 all at the baseline with 0 bucket and 0 reply changes, seven-step verbatim, full suite 2,362 passed, 1 known failure; at merge: gate files, graph and reading tests 458 passed | **91/108**: one English question right that was held; **one English which-person turn held that was right** (`graph-step-3s1.json`); 0 wrong, 0 violations. A lost pass: to be restored before the next step is merged |

## Identity graph, step 3, statements 2: thing identity

| Step | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| 3 (statements 2): one thing, one node: a mention whose words are all words of one existing thing node, in order, is its alias (form `short`) when exactly one fits; two that fit stay apart; a word the node lacks is another thing | 821e7b1, merged 347d0cc | chat about 90 min; plan manager 25 min (masked graph dumps at two commits) | reported 15:40, merged 15:44, scored 15:49 | chat: dev v3–v6 check halves at effort 0 and 3 at the baseline, 0 bucket and 0 reply changes; seven-step verbatim; full suite 2,365 passed, 1 known failure. At merge: gate files, graph and reading tests 461 passed | **90/108**: the which-person turn is back (12 of 12); the reply after it is held again, as it was at the baseline. Against step 2: 0 bucket changes; 0 wrong, 0 violations (`graph-step-3s2.json`) |

What the masked dump showed: before the reader named holder and thing, the string
split made four holder nodes for two people and, by accident, one thing node; with
the parts the holders were right and the thing was two nodes. The thing of that
conversation is mentioned three ways (two modifiers and a two-word name; one
modifier and the last word; the modifier alone).

## Identity graph, step 3, question side

| Step | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| 3 (questions): lookup, pointers, which-person and corrections by node; declared holders take the node's name; a named thing with a described person asks among that thing's holders; `graph.key` gives the replay's key for a node pair | 83a9252, ec140d4, 8c9a15b, bbd8849, merged d1a9d49 | chat about 120 min over the afternoon; plan manager 10 min | waited on the thing-identity fix from 13:30 to 15:50; reported 16:12, merged 16:13, scored 16:19 | chat's full suite 2,373 passed, 1 known failure (gate files left out), no re-pin; gate files, graph, corrections and reading tests at merge: 477 passed | **90/108, 0 bucket changes**, 3 reply texts changed, 0 wrong, 0 violations (`graph-step-3q.json`). The held reply the chat expected to move did not: it is a two-sentence turn (the name, then the question again) |

## Identity graph, step 3, statements 3: the thing node a mention means

| Step | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| 3 (statements 3): a mention of a thing in its other number, or by some of its words in order, is read as the thing node its holder counts: a candidate (`_read_thing_alias`, effort 2) checked by replay, ranked, a tie held | eb90b1f, merged 76671f7 | chat about 40 min; plan manager 8 min | reported 16:31, merged 16:33, scored 16:39 | chat: dev v3–v6 check halves at effort 0 and 3 at the baseline, 0 bucket and 0 reply changes; seven-step verbatim; full suite 2,370 passed, 1 known failure. At merge: gate files, graph, corrections and reading tests 482 passed | gate **90/108** unchanged; **statements recorded 144 → 146 of 150**: the two English transfers the string-key wrong-thing candidate had to exclude are read through the node (the thing they name is a mention of the node their giver counts); 0 wrong, 0 violations (`graph-step-3s3.json`) |

The 18 held answerable turns at 76671f7, as chains (S statement, Q question, W
which-person, C correction, M missing premise, Y why, U unsupported; `ok` or the
hold reason). Eleven dialogues:

| Lang | Chain | Root |
| --- | --- | --- |
| en | S S S W Q(not read) M | the reply to a which-person ask, two sentences |
| en | S S W Q U Q(unread_event) | a declined request is kept as an unread event and holds the next question |
| en | S S S C(not read) Q Q Y | a correction of three tokens: marker, number, number |
| en | S S S W C(reference_value_unclear) Q Q | a correction whose statement is now recorded |
| en | S S S W Q(not read) U Q | the reply to a which-person ask |
| ko | S S Q M(not read) S(no_reading) Q U | a transfer with no thing |
| ko | S(not read) S S(unread_event) Q Q(tie) Q | a holding that lists two things |
| ko | S S S(unknown_word) W C(reference_no_event) Q Q | a transfer, amount one, the verb not known in its frame |
| ko | S S S Q Y(not read) Q(not read) | a why, then a one-word question after a restart |
| ko | S S Q C(not read) Q Y Q | a correction with two markers |
| ko | S S S W Q(unresolved) U Q(unresolved) | the reply to a which-person ask |

## On nodes: the reply to a which-person ask

| Cause (exam chain) | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| `S S S W Q(not read)`: the reply is a name with a word or two, then the question again, naming the holder and no thing; and the thing of the ask had been said with one of its words only | 7e0ed68 (a thing said with some of its words is its node), 534b32e (the reply's first sentence is tried as a named reply), merged 947f503 | chat about 45 min; plan manager 8 min | reported 16:55, merged 16:57, scored 17:03 | chat's full suite 2,385 passed, 1 known failure (gate files left out), no re-pin; gate files, graph, corrections and reading tests at merge: 489 passed | **93/108 (86.1%)**, +3, English 49 of 54, Korean 44 of 54, 0 wrong, 0 violations (`graph-step-3q2.json`). Expected by the chat: the two English replies; they moved, and the question behind one of them |

## On nodes: the other keys of a holder, and a turn that changes nothing

| Cause | Patch (commit) | Work | Wait | Regression | Frozen exam |
| --- | --- | --- | --- | --- | --- |
| (conversion) `_read_other_keys` on nodes: a key that kept a case particle names its holder, the holder node's other keys are the candidates; the string helper `_other_keys` is gone | 3c25246 with 2d67f08, merged with the next | chat about 45 min | — | chat: dev v3–v6 check halves at effort 0 and 3 at the baseline, 0 bucket changes, 2 reply texts (a title kept as said); seven-step verbatim; full suite 2,378 passed, 1 known failure | expected: no exam turn |
| (exam chain `S S W Q U Q(unread_event)`) a declined request was kept as an unread event and held the next question | b0df428, both merged as fe0f976 | chat about 25 min; plan manager 12 min for both | reported 17:12 and 17:15, merged 17:21, scored 17:29 (one run for both, the machine was hot) | chat: full suite 2,393 passed, 1 known failure, no re-pin. At merge: gate files, graph, corrections and reading tests 497 passed | **94/108 (87.0%)**, +1: the English question after the declined request, as the chat expected; English 50 of 54, Korean 44 of 54; 0 wrong, 0 violations (`graph-step-3s4q3.json`) |

| (request G7-5, a wrong identity) a Korean holding whose thing has modifiers put them into the holder's node | a96f7ff, merged 58a1dc6 | chat about 15 min; plan manager 7 min | reported 17:31, merged 17:32, scored 17:38 | chat: dev v3–v6 check halves at effort 0 and 3 at the baseline, 0 bucket changes; seven-step verbatim; full suite 2,381 passed, 1 known failure. At merge: gate files, graph, corrections, round-7 and seven-step tests 270 passed | **94/108, 0 bucket changes**, 1 reply text, 0 wrong, 0 violations (`graph-step-3s5.json`) |

| (safety, found by the questions chat on invented sentences) an unread turn that names its holder by a pointer did not hold the questions about what it may have changed: a confident answer after an unread change | cc94662, merged 390c833 | chat about 20 min; plan manager 5 min | reported 17:39, merged 17:40; the exam run then sat through the laptop's sleep from about 18:10 to 21:40 and ended 21:44 | chat: full suite (-n 4) 2,400 passed, 1 known failure; 7 new tests, 6 fail without the fix; no dev check turn changes. At merge: gate files, graph, corrections and reading tests 277 passed | **94/108, 0 bucket changes, 0 reply texts**, 0 wrong, 0 violations (`graph-safety-pointer.json`) |

| (2026-10-01; corrections on nodes, found on the exam) a correction found its event by string keys, so a statement whose thing was read through the thing node and its rewrite with the amount changed were not the same event; the first merge of the fix (7250d7f) scored 94 with 4 wrong and 4 retracted-evidence violations: the carried reading of a rewritten statement still cited the corrected statement's original wording | 51caf1e, merged 7250d7f (not pushed); 75c29b1 (the rewrite's reading cites the correction turn: spans, source and canonical wording are the rewrite's own), merged 5a4fe5d | chat — ; plan manager about 9 min (08:55 to 09:03) | 7250d7f merged 02:58 and held unpushed; fix committed and merged 08:57, scored 09:03 | worktree: round-7 questions, corrections and graph tests 112 passed. At merge: gate files, graph, corrections, round-7 and reading tests 512 passed | **98/108 (90.7%)**, +4: four English answerable turns and two English corrections from hold to correct; English 54 of 54, Korean 44 of 54; 0 wrong, 0 violations (`graph-corrections-evidence.json`) |

| (2026-10-01; identity graph step 3, statements 6) `_read_unsaid_thing` on nodes: a holder said without a thing is a holder node, its candidates are the thing nodes the conversation counts; a holding that names no thing took the conversation's thing even when two things were counted | b87e72a, eae58b2 (test of request G7-5), ad12b5d, merged a05733d | chat — ; plan manager about 7 min (09:03 to 09:10) | ad12b5d committed 06:30; merged 09:03, scored 09:10 | at merge: gate files, graph, corrections, round-7 and reading tests 515 passed. Full suite (-n 4, loadfile) 2,446 passed, 3 known failures (a first run had one more: a sqlite disk I/O error while two workers built the definitions cache; it passed alone and on the rerun). Dev v6 check: effort 3 189/234, effort 0 109/234, 0 wrong, 0 violations | **98/108, 0 bucket changes**, 4 reply texts, 0 wrong, 0 violations (`graph-step-3s6.json`) |

| (2026-10-01; safety, found on public word problems, SVAMP `chal-266`) a confident wrong answer after an unread turn that names no holder: `S S(not read) S Q` answered the last stated count, because a later statement about the asked key released the hold and the unread turn was matched to keys by substring | 1d0751e (an unread turn marks every thing node it mentions; a holder's count is held, naming the turn, until every marked thing of that holder is said again), merged ea005a5 | chat about 80 min, with one renamed method after 164 failures on its first heavy run; plan manager about 30 min, 13 of them lost to a wait loop that matched its own command line | reported 14:17, merged 14:19, scored 14:43 together with the overlay view merge eca0367 | chat: 9 tests, 6 fail without the fix; dev v3–v6 check halves at effort 3 identical before and after, 0 bucket changes; full suite 2,482 passed, 1 known failure. At merge: full suite 2,641 passed, 3 known failures | **98 of 108, 0 wrong, 0 violations**, 0 bucket changes, 0 reply texts changed ([graph-safety-unread-thing.json](dialogue-gate-2026-09-22/graph-safety-unread-thing.json)); the SVAMP problem is now held |

| (2026-10-01; correction, a swap said with no name) a correction with a swap word and no holder named was left unread, and three such forms let the next question answer the unswapped count | 81ddb14, merged eda43a3 | chat about 30 min; plan manager 12 min | reported 14:50, merged 14:52, scored 15:05 | chat: 4 tests, 3 fail without the fix; dev v3–v6 at effort 3 identical, 0 bucket changes; full suite 2,560 passed, 1 known failure. At merge: 528 passed | 98 of 108, 0 wrong, no turn changed: the exam's swap correction has no swap word; it restates the transfer with one holder named and the other by a non-name word. Masked trace sent back to the chat |

| (2026-10-01; a wrong identity, seen on invented sentences and behind the SVAMP wrong answer) a container and its content were one thing node: `43 packs of quills` then `8 quills` showed one count, 8; the same join in Korean | 786b089 (head and content by the pack's partitive word or counter nouns; a shorter mention joins only with a word of the head), merged d7ebbb4 | chat about 50 min; plan manager 10 min | reported 15:08, merged 15:09, scored 15:18 | chat: 8 tests in both languages; dev v3–v6 at effort 3 identical, 0 bucket changes; full suite 2,617 passed, 1 known failure. At merge: 535 passed | 98 of 108, 0 wrong, 0 violations, no turn changed. Next cause from the chat: one thing counted in two units, the second count replaces the first |

| (2026-10-01; safety, a wrong state found by the statements chat) one thing counted in two units: the second count replaced the first, and both `몇 개` and `몇 묶음` answered the last number | 043b0da, b669647 (two counts are kept, nothing is converted; a question in the pack's first unit is answered, one in another unit or in none is held), request G7-6 for M2, merged 5c90bf7 | chat about 60 min of work across the laptop's sleep; plan manager 10 min | reported 21:50 and 23:45, merged 23:50, scored 00:00 | chat: dev v3–v6 at effort 3 identical before and after, 0 bucket changes; 140 own and graph tests; full suite 2,622 passed, 1 known failure on the first form. At merge: 540 passed | 98 of 108, 0 wrong, 0 violations, no turn changed |

| (2026-10-02; four wrong answers found on invented sentences by the questions chat, and the request they need) an unread sentence was dropped by its surface shape as changing nothing (`Burglars stole the quills.` answered the old count); a sentence read only as an event shape, in a turn nothing read, was not kept as unread; a count was answered while a which-event question was open; a readable statement in a turn nothing applied was lost | fd0d996, 06593b3, a6a7a94, d76e084, and d3d8a0b (a bare imperative with a declared request verb and object opener is a request: 31 verbs and 9 openers in the English pack, the structure in code), merged 8e0277a | chat across the laptop's sleep; plan manager about 40 min | reported 01:05, scored by revision 01:15, merged 01:18, scored on main 01:30 | chat: dev v3–v6 at effort 3 identical at every revision, no answer becomes a hold; two long-known wrong dev turns (dev4_ko_c_19) become holds; 53 cases for the request rule; full suite 2,673 passed, 1 known failure. At merge: full suite 2,720 passed, 3 known failures | by revision: 97 of 108 after the four fixes (one English answer after a request not recognised as one went to a hold), **98 of 108, 0 wrong, 0 violations** with the request rule; on main the same, no turn changed against the last report ([release-safety-fixes.json](dialogue-gate-2026-09-22/release-safety-fixes.json)) |
