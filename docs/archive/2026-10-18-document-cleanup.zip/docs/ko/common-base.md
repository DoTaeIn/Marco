# 공통 대화 기반

`main`은 게임과 범용 문서 질의가 함께 쓰는 기반이다. 둘은 같은 지식 그래프를
**목적과 의도가 흩어진 지도**로 본다. 입력은 지도에서 현재 주제와 의도를 찾고,
출력은 그 주제에서 목적까지 이어지는 길 또는 문서 근거로만 만든다.

## 하나의 대화 계약

`nai.Conversation`은 그래프 종류를 감춘다.

```python
from nai import Conversation

chat = Conversation("graphs/graph_의료.kg")       # 게임/NPC형
# chat = Conversation("data/법지식/지식그래프.json") # 문서 안내형
reply = chat.reply("이 경우 어떤 근거가 필요해?")
print(reply.text, reply.intent, reply.topic, reply.path)
```

매 턴 결과는 다음을 보장한다.

- `intent`: 사용자가 원하는 답의 모양. 문서형은 정의·이유·방법·조건·경로 등을,
  게임형은 인정·되묻기·반박 같은 대화 판정을 돌려준다.
- `topic`: 실제로 지도에서 고른 노드다. 고르지 못하면 `None`이다.
- `path`: 게임형은 `증명`/`충족` 관계만 따라 목적 노드까지 간 경로다. 문서형은
  답의 근거 주제를 담는다. UI는 이 값을 그대로 강조하면 된다.
- `text`: 그래프/원문에 있는 표현을 고르고 조립한 말이다. 찾지 못한 사실은 만들지
  않고, 되묻거나 근거를 찾지 못했다고 답한다.

문서형의 대화 기억 갱신도 공통 층이 맡는다. 그래서 첫 질문의 주제가 다음 턴의
생략된 주어를 해석하는 데 사용된다.

## 그래프 생성과 실행

```bash
# 문서 폴더 -> 설명형 지식 그래프
python -m marco.runtime.conversation --build data/법지식 --out data/법지식/지식그래프.json

# 한 번 묻기: 답뿐 아니라 의도·주제·경로를 JSON으로 받는다
python -m marco.runtime.conversation graphs/graph_의료.kg --ask "진단에 어떤 근거가 필요해?"

# 여러 턴 대화
python -m marco.runtime.conversation data/법지식/지식그래프.json --chat
```

게임 그래프는 사람이 `.kg`로 저작한다. 문서 그래프는 `--build`가 `.txt`와 `.md`에서
자동 생성한다. 두 경우 모두 같은 대화 API를 사용하므로, 게임 브랜치는 캐릭터의
인격·상태를, 범용 브랜치는 문서 수집·관계 확장을 독립적으로 발전시킬 수 있다.
