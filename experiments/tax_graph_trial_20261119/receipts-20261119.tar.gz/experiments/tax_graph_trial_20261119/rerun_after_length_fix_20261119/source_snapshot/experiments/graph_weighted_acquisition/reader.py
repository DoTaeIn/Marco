"""Piece-level, edge-scoring reader.

No sentence templates. A text is cut into pieces that were each seen in
training (connecting strings, fixed words, stem+ending words) plus free values.
Every argument then chooses a head and a role, scored by integer counts of what
that piece did in training. The best whole reading wins only with a clear,
fully observed lead; every count used is kept so the reading can be explained.

Nothing here is a neural network, an embedding or a token predictor. The model
is a JSON file of counts with the ids of the training examples behind them.
"""
import itertools
import json
import math

from experiments.graph_example_acquisition import native
from . import merge as M
from . import weights as W

SCHEMA = 'graph-piece-reader-v1'
DEFAULT_POLICY = {'alpha': [1, 2], 'margin_ratio': 3, 'beam': 16, 'max_value_chars': 40,
                  'max_assignments': 5000, 'origins_kept': 5}
ANY = '*'


def key(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


# ---------------------------------------------------------------- building

def _covered(cue, start, used):
    """Inside a larger piece that is itself used: already explained, not left over."""
    end = start + len(cue)
    return any(s <= start and end <= s + len(c) and c != cue for c, s in used)


def occurrences(text, cue):
    out, pos = [], text.find(cue)
    while pos >= 0:
        out.append(pos)
        pos = text.find(cue, pos + 1)
    return out


def _gap_bounds(mentions, text, i):
    start = 0 if i == 0 else mentions[i - 1][0][1]
    end = len(text) if i == len(mentions) else mentions[i][0][0]
    return start, end


def _ref(span, mentions, text, arg, head):
    """Describe an evidence span relative to an argument and its head."""
    span = tuple(span)
    for name, index in (('ARG', arg), ('HEAD', head)):
        if index is None:
            continue
        if span == tuple(mentions[index][0]):
            return [name]
        for side, gap in (('LEFT', index), ('RIGHT', index + 1)):
            start, end = _gap_bounds(mentions, text, gap)
            if start <= span[0] and span[1] <= end and start < end:
                return [name + '_' + side, text[start:end], span[0] - start, span[1] - start]
    return None


def build(examples, policy=None):
    policy = dict(DEFAULT_POLICY, **(policy or {}))
    kept = policy['origins_kept']
    tables, cues, skipped = {}, {}, []

    def count(table, cue, label, origin, forms=()):
        """One more observation. `origin` is a training example id, or a list of them."""
        cell = tables.setdefault(table, {}).setdefault(cue, {}).setdefault(label, {'n': 0, 'origins': []})
        cell['n'] += 1
        for one in origin if isinstance(origin, list) else [origin]:
            if one not in cell['origins'] and len(cell['origins']) < kept:
                cell['origins'].append(one)
        for form in forms:
            if form not in cell.setdefault('forms', []):
                cell['forms'].append(form)

    def cue_count(cue, name, origin):
        cell = cues.setdefault(cue, {}).setdefault(name, {'n': 0, 'origins': []})
        cell['n'] += 1
        if origin not in cell['origins'] and len(cell['origins']) < kept:
            cell['origins'].append(origin)

    head_surfaces, texts = {}, []
    for ex in examples:
        try:
            graph, text, origin = ex['graph'], ex['text'], ex['id']
            mentions, gaps = W._segments(graph, text)
            opened = W._open_ids(graph)
            heads = {s for s, p, o in graph['edges'] if isinstance(o, str)}
            index_of = {}
            for i, (span, node, _) in enumerate(mentions):
                index_of.setdefault(node['id'], []).append(i)
            head_order = [i for i, (_, node, _) in enumerate(mentions) if node['id'] in heads]
            rows, used, kinds = [], [], []
            for i, (span, node, _) in enumerate(mentions):
                surface = text[slice(*span)]
                kinds.append('head' if node['id'] in heads else 'value' if node['id'] in opened else 'closed')
                if kinds[-1] != 'value':
                    used.append((surface, span[0]))
                if node['id'] in heads:
                    literals = sorted([p, o['literal']] for s, p, o in graph['edges']
                                      if s == node['id'] and isinstance(o, dict) and 'literal' in o)
                    entry = key({'type': node['type'], 'literals': literals})
                    rows.append(('head', surface, entry, origin))
                    seen_in = head_surfaces.setdefault(entry, {}).setdefault(surface, [])
                    if origin not in seen_in and len(seen_in) < kept:
                        seen_in.append(origin)
                elif node['id'] in opened:
                    rows.append(('value_type', gaps[i + 1], node['type'], origin))
                    rows.append(('value_length', ANY, str(len(surface)), origin))
                else:
                    entry = key({'type': node['type'], 'project': node['id'] in graph['project']})
                    rows.append(('closed', surface, entry, origin))
            for i, gap in enumerate(gaps):
                where = 'start' if i == 0 else 'end' if i == len(gaps) - 1 else 'mid'
                rows.append(('gap', where, gap, origin))
                rows.append(('gap_after', kinds[i - 1] if i else 'start', gap, origin))
                if i < len(kinds):
                    rows.append(('kind_after', gap, kinds[i], origin))
                if gap.strip():
                    start = _gap_bounds(mentions, text, i)[0]
                    used.append((gap.strip(), start + len(gap) - len(gap.lstrip())))
            frames = {i: [] for i in head_order}
            for (s, p, o), evidence in zip(graph['edges'], graph['edge_spans']):
                if s not in heads:
                    if p == 'value':
                        refs = [_ref(e, mentions, text, index_of[s][0], None) for e in evidence]
                        if None in refs:
                            raise ValueError('value evidence outside the mention')
                        rows.append(('evidence', 'value', key(refs), origin))
                    continue
                h = index_of[s][0]
                if isinstance(o, dict):
                    refs = [_ref(e, mentions, text, None, h) for e in evidence]
                    if None in refs:
                        raise ValueError('literal evidence outside the head')
                    rows.append(('evidence', 'literal:' + p, key(refs), origin))
                    continue
                places = index_of[o]
                if len(places) > 1:
                    places = [i for i in places if list(mentions[i][0]) in evidence] or places[:1]
                a = places[0]
                refs = [_ref(e, mentions, text, a, h) for e in evidence]
                if None in refs:
                    raise ValueError('role evidence outside argument and head')
                offset = head_order.index(h) - sum(1 for j in head_order if j < a)
                rows += [('attach', ANY, str(offset), origin), ('role_right', gaps[a + 1], p, origin),
                         ('role_left', gaps[a], p, origin), ('evidence', 'role:' + p, key(refs), origin)]
                if mentions[a][1]['id'] not in opened:
                    rows.append(('role_surface', text[slice(*mentions[a][0])], p, origin))
                frames[h].append(p)
            for h, roles in frames.items():
                span, node, _ = mentions[h]
                literals = sorted([p, o['literal']] for s, p, o in graph['edges']
                                  if s == node['id'] and isinstance(o, dict) and 'literal' in o)
                rows.append(('frame', key({'type': node['type'], 'literals': literals}), key(sorted(roles)), origin))
                rows.append(('repeat_role', ANY, 'yes' if len(set(roles)) < len(roles) else 'no', origin))
            for row in rows:
                count(*row)
            texts.append((text, set(used), origin))
        except (ValueError, KeyError, TypeError) as error:
            skipped.append({'example': ex.get('id'), 'reason': str(error)})
    # Stem + ending: two fixed words with the same meaning that share a beginning.
    for entry, surfaces in head_surfaces.items():
        for a, b in itertools.combinations(sorted(surfaces), 2):
            n = 0
            while n < min(len(a), len(b)) and a[n] == b[n]:
                n += 1
            if 0 < n < len(a) and n < len(b):
                # Origins are the training examples the two word forms came from.
                count('stem', a[:n], entry, surfaces[a] + surfaces[b], forms=(a, b))
                count('ending', ANY, a[n:], surfaces[a], forms=(a,))
                count('ending', ANY, b[n:], surfaces[b], forms=(b,))
    # A fixed word that ends in a learned ending shares its beginning with unseen forms.
    for entry, surfaces in head_surfaces.items():
        for surface in sorted(surfaces):
            for ending in list(tables.get('ending', {}).get(ANY, {})):
                stem = surface[:len(surface) - len(ending)]
                if stem and surface.endswith(ending) and entry not in tables.get('stem', {}).get(stem, {}):
                    count('stem', stem, entry, surfaces[surface], forms=(surface,))
    # Every place a known piece occurs in training text: was it used as structure or not?
    known = {cue for _, used, _ in texts for cue, _ in used}
    for text, used, origin in texts:
        for cue in known:
            for start in occurrences(text, cue):
                if (cue, start) in used:
                    cue_count(cue, 'used', origin)
                elif not _covered(cue, start, used):
                    cue_count(cue, 'unused', origin)
    return {'schema': SCHEMA, 'policy': policy, 'examples': len(examples) - len(skipped), 'tables': tables,
            'cues': cues, 'identity': M.identity_counts(examples), 'skipped': skipped}


# ---------------------------------------------------------------- scoring

class _Scorer:
    def __init__(self, model):
        self.model = model
        num, den = model['policy']['alpha']
        self.alpha = num / den
        self._lengths = {}

    def row(self, table, cue):
        return self.model['tables'].get(table, {}).get(cue, {})

    def term(self, what, piece, table, cue, label, shown=None):
        row = self.row(table, cue)
        seen = row.get(label, {}).get('n', 0)
        total = sum(c['n'] for c in row.values())
        value = math.log((seen + self.alpha) / (total + self.alpha * (len(row) + 1)))
        others = sorted(((c['n'], other) for other, c in row.items() if other != label), reverse=True)[:3]
        return {'what': what, 'piece': piece, 'decision': shown if shown is not None else label, 'given': cue,
                'count': seen, 'of': total, 'origins': row.get(label, {}).get('origins', []),
                'forms': row.get(label, {}).get('forms', []), 'log': value,
                'alternatives': [{'decision': other, 'count': n} for n, other in others]}

    def length_term(self, surface):
        """How likely a free value is to be this long, read from the lengths seen in training.

        A value is modelled as continuing or stopping at each character. Up to the longest
        length seen, the stop rate at each length is counted directly; past it, the overall
        stop rate per character is used. So an unseen length is allowed but costs more the
        longer it is. This term grades a reading; it never marks it as unseen.
        """
        length = len(surface)
        if length not in self._lengths:
            row = {int(k): c['n'] for k, c in self.row('value_length', ANY).items()}
            total, chars, longest = sum(row.values()), sum(k * n for k, n in row.items()), max(row, default=0)
            pooled = (total + self.alpha) / (chars + 2 * self.alpha)
            value = 0.0
            for k in range(1, length + 1):
                reached = sum(n for size, n in row.items() if size >= k)
                stop = (row.get(k, 0) + self.alpha) / (reached + 2 * self.alpha) if k <= longest else pooled
                value += math.log(stop if k == length else 1 - stop)
            self._lengths[length] = (value, row.get(length, 0), total, longest)
        value, seen, total, longest = self._lengths[length]
        cell = self.row('value_length', ANY).get(str(length), {})
        return {'what': 'length of a free value', 'piece': surface, 'decision': '%d characters' % length,
                'given': 'longest seen in training: %d' % longest, 'count': seen, 'of': total,
                'origins': cell.get('origins', []), 'forms': [], 'log': value, 'alternatives': [], 'graded': True}

    def cue_term(self, cue, used):
        row = self.model['cues'].get(cue, {})
        a, b = row.get('used', {}).get('n', 0), row.get('unused', {}).get('n', 0)
        seen = a if used else b
        name = 'used' if used else 'unused'
        return {'what': 'known piece used as structure' if used else 'known piece left unused',
                'piece': cue, 'decision': name, 'given': cue, 'count': seen, 'of': a + b,
                'log': math.log((seen + self.alpha) / (a + b + 2 * self.alpha)),
                'origins': row.get(name, {}).get('origins', []),
                'alternatives': [{'decision': 'unused' if used else 'used', 'count': b if used else a}]}


# ---------------------------------------------------------------- tiling

def _stripped(text, start, end):
    """The non-blank part of a connecting string and where it starts."""
    gap = text[start:end]
    return gap.strip(), start + len(gap) - len(gap.lstrip())


def _tilings(text, model, scorer):
    """Best ways to cut the text into known pieces and free values."""
    tables, policy = model['tables'], model['policy']
    gaps = tables.get('gap', {})
    beam, n = policy['beam'], len(text)
    mid = [g for g in gaps.get('mid', {}) if g]
    ends = list(gaps.get('end', {}))
    stems, endings = tables.get('stem', {}), tables.get('ending', {}).get(ANY, {})

    def gain(cue):
        """How much better it is to use a known piece than to leave it unused."""
        if not cue or cue not in model['cues']:
            return 0.0
        return scorer.cue_term(cue, True)['log'] - scorer.cue_term(cue, False)['log']

    def gap_score(prev, gap, nxt):
        value = gain(gap.strip()) + scorer.term('', gap, 'gap_after', prev, gap)['log']
        if nxt:
            value += scorer.term('', nxt, 'kind_after', gap, nxt)['log']
        return value

    def boundary(pos):
        return any(text.startswith(g, pos) for g in mid) or any(text[pos:] == g for g in ends)

    def mentions_at(pos):
        out = []
        for surface in tables.get('head', {}):
            if text.startswith(surface, pos):
                out.append((gain(surface), ('head', pos, pos + len(surface), 'word')))
        for stem in stems:
            if text.startswith(stem, pos):
                for ending in endings:
                    end = pos + len(stem) + len(ending)
                    if text.startswith(ending, pos + len(stem)) and text[pos:end] not in tables.get('head', {}):
                        out.append((0.0, ('head', pos, end, 'stem:' + stem)))
        for surface in tables.get('closed', {}):
            if text.startswith(surface, pos):
                out.append((gain(surface), ('closed', pos, pos + len(surface), 'word')))
        for end in range(pos + 1, min(n, pos + policy['max_value_chars']) + 1):
            if boundary(end):
                # A free value pays for its length, so swallowing a clause is never free.
                cost = scorer.length_term(text[pos:end])['log']
                out.append((cost, ('value', pos, end, 'value')))
        return out

    memo, cut = {}, [False]

    def cut_check(found):
        # Dropping a candidate that scores the same as one that is kept is an arbitrary pick.
        if len(found) > beam and abs(found[beam][0] - found[beam - 1][0]) < 1e-9:
            cut[0] = True

    def after_mention(pos, prev):
        if (pos, prev) in memo:
            return memo[pos, prev]
        found = []
        for gap in ends:
            if text[pos:] == gap:
                found.append((gap_score(prev, gap, None), (('gap', pos, n, 'end'),)))
        for gap in mid:
            if text.startswith(gap, pos):
                here = pos + len(gap)
                for score, piece in mentions_at(here):
                    for rest_score, rest in after_mention(piece[2], piece[0]):
                        found.append((gap_score(prev, gap, piece[0]) + score + rest_score,
                                      (('gap', pos, here, 'mid'), piece) + rest))
        found.sort(key=lambda item: (-item[0], item[1]))
        cut_check(found)
        memo[pos, prev] = found[:beam]
        return memo[pos, prev]

    out = []
    for gap in gaps.get('start', {}):
        if text.startswith(gap):
            for score, piece in mentions_at(len(gap)):
                for rest_score, rest in after_mention(piece[2], piece[0]):
                    out.append((gap_score('start', gap, piece[0]) + score + rest_score,
                                (('gap', 0, len(gap), 'start'), piece) + rest))
    out.sort(key=lambda item: (-item[0], item[1]))
    cut_check(out)
    return out[:beam], cut[0]


# ---------------------------------------------------------------- reading

def _resolve(refs, spans, text, arg, head):
    """Turn a learned evidence description back into character spans."""
    out = []
    for ref in refs:
        index = arg if ref[0].startswith('ARG') else head
        if index is None:
            return None
        if len(ref) == 1:
            out.append(list(spans[index]))
            continue
        gap = index if ref[0].endswith('LEFT') else index + 1
        start = 0 if gap == 0 else spans[gap - 1][1]
        end = len(text) if gap == len(spans) else spans[gap][0]
        if text[start:end] != ref[1]:
            return None
        out.append([start + ref[2], start + ref[3]])
    return out


def _evidence(model, name, spans, text, arg, head):
    """Spans for an edge from the most common learned description that fits.

    Returns (spans, tied): tied when another description that fits here was seen
    equally often and points at different text.
    """
    row = model['tables'].get('evidence', {}).get(name, {})
    fits = []
    for refs, cell in sorted(row.items(), key=lambda item: (-item[1]['n'], item[0])):
        found = _resolve(json.loads(refs), spans, text, arg, head)
        if found:
            fits.append((cell['n'], found))
    if not fits:
        return None, False
    return fits[0][1], any(n == fits[0][0] and found != fits[0][1] for n, found in fits[1:])


def _readings(text, model, scorer, tiling_score, pieces):
    policy = model['policy']
    mentions = [p for p in pieces if p[0] != 'gap']
    spans = [(p[1], p[2]) for p in mentions]
    gaps = [text[p[1]:p[2]] for p in pieces if p[0] == 'gap']
    heads = [i for i, p in enumerate(mentions) if p[0] == 'head']
    if not heads:
        return []
    base, used, previous = [], set(), 'start'
    for index, p in enumerate(pieces):
        if p[0] == 'gap':
            gap = text[p[1]:p[2]]
            cue, start = _stripped(text, p[1], p[2])
            if cue:
                used.add((cue, start))
            base.append(scorer.term('connecting piece after a ' + previous, gap, 'gap_after', previous, gap))
            if index + 1 < len(pieces):
                base.append(scorer.term('what follows this piece', pieces[index + 1][0], 'kind_after', gap,
                                        pieces[index + 1][0]))
        else:
            previous = p[0]
            if p[0] != 'value':
                used.add((text[p[1]:p[2]], p[1]))
    for cue in model['cues']:
        for start in occurrences(text, cue):
            if (cue, start) in used:
                base.append(scorer.cue_term(cue, True))
            elif not _covered(cue, start, used):
                base.append(scorer.cue_term(cue, False))
    # Fixed words and free values: every meaning seen in training stays a candidate, so two
    # equally common meanings end as a tie between readings and never as a silent pick.
    meanings = []
    for i, p in enumerate(mentions):
        surface = text[p[1]:p[2]]
        if p[0] == 'head':
            table, cue = ('head', surface) if p[3] == 'word' else ('stem', p[3][5:])
            found = []
            for label in sorted(scorer.row(table, cue)):
                terms = [scorer.term('meaning of a fixed word', surface, table, cue, label)]
                if p[3] != 'word':
                    terms.append(scorer.term('word ending', surface[len(cue):], 'ending', ANY, surface[len(cue):]))
                found.append((json.loads(label), terms))
        elif p[0] == 'closed':
            found = [(json.loads(label), [scorer.term('meaning of a fixed word', surface, 'closed', surface, label)])
                     for label in sorted(scorer.row('closed', surface))]
        else:
            length = scorer.length_term(surface)
            found = [({'type': kind}, [scorer.term('kind of a free value', surface, 'value_type', gaps[i + 1], kind),
                                       length])
                     for kind in sorted(scorer.row('value_type', gaps[i + 1])) or ['unknown']]
        if not found:
            return []
        meanings.append(found)
    size = 1
    for found in meanings:
        size *= len(found)
    if size > policy['max_assignments']:
        return [{'incomplete': 'too many meanings'}]
    out = []
    for combo in itertools.product(*meanings):
        entries = {i: entry for i, (entry, _) in enumerate(combo)}
        chosen = base + [t for _, terms in combo for t in terms]
        found = _assign(text, model, scorer, pieces, mentions, spans, gaps, heads, entries, chosen)
        if found and 'incomplete' in found[0]:
            return found
        out += found
    return out


def _assign(text, model, scorer, pieces, mentions, spans, gaps, heads, entries, base):
    policy = model['policy']
    # Every argument chooses a head and a role.
    args = [i for i in range(len(mentions)) if i not in heads]
    options = []
    for a in args:
        surface, left, right = text[slice(*spans[a])], gaps[a], gaps[a + 1]
        # Most specific evidence first: a fixed word that was itself seen in a role
        # speaks for itself; a free value is read from the pieces around it.
        own = mentions[a][0] == 'closed' and scorer.row('role_surface', surface)
        roles = set(own) if own else set(scorer.row('role_right', right)) | set(scorer.row('role_left', left))
        found = []
        for rank, h in enumerate(heads):
            offset = str(rank - sum(1 for j in heads if j < a))
            for role in sorted(roles):
                terms = [scorer.term('which head', surface, 'attach', ANY, offset,
                                     'head %r (offset %s)' % (text[slice(*spans[h])], offset))]
                if own:
                    terms.append(scorer.term('role of this fixed word', surface, 'role_surface', surface, role))
                else:
                    terms += [scorer.term('role from the piece after it', surface, 'role_right', right, role),
                              scorer.term('role from the piece before it', surface, 'role_left', left, role)]
                found.append((sum(t['log'] for t in terms), all(t['count'] > 0 for t in terms), h, role, terms))
        supported = [f for f in found if f[1]]
        found = supported or sorted(found, key=lambda f: -f[0])[:2]
        if not found:
            return []
        options.append(found)
    size = 1
    for found in options:
        size *= len(found)
    if size > policy['max_assignments']:
        return [{'incomplete': 'too many role assignments'}]
    repeat_seen = scorer.row('repeat_role', ANY).get('yes', {}).get('n', 0) > 0
    out = []
    for choice in itertools.product(*options):
        by_head = {h: [] for h in heads}
        for a, (_, _, h, role, _) in zip(args, choice):
            by_head[h].append((role, a))
        if not repeat_seen and any(len({r for r, _ in roles}) < len(roles) for roles in by_head.values()):
            continue
        terms = list(base)
        for _, _, _, _, option_terms in choice:
            terms += option_terms
        for h, roles in by_head.items():
            entry = key({'type': entries[h]['type'], 'literals': entries[h].get('literals', [])})
            terms.append(scorer.term('set of roles for this head', text[slice(*spans[h])], 'frame', entry,
                                     key(sorted(r for r, _ in roles))))
        graph, tied = _graph(text, model, mentions, spans, entries, by_head)
        if graph is None:
            continue
        merged = None
        try:
            merged = M.merge_graph(graph, text, model.get('identity', {}))
        except ValueError:
            pass
        graph = merged or graph
        score = sum(t['log'] for t in terms)
        supported = all(t['count'] > 0 for t in terms if not t.get('graded'))
        out.append({'graph': graph, 'score': score, 'supported': supported, 'terms': terms, 'tied_evidence': tied,
                    'pieces': [{'kind': p[0], 'text': text[p[1]:p[2]], 'span': [p[1], p[2]], 'how': p[3]}
                               for p in pieces], 'merged': merged is not None})
    return out


def _graph(text, model, mentions, spans, entries, by_head):
    """Build the graph of one reading. Returns (graph, tied evidence?) or (None, False)."""
    nodes, edges, evidence, project, tied = [], [], [], [], False

    def add(edge, name, arg, head):
        nonlocal tied
        found, tie = _evidence(model, name, spans, text, arg, head)
        if not found:
            return False
        tied |= tie
        edges.append(edge)
        evidence.append(found)
        return True

    for i, p in enumerate(mentions):
        nodes.append({'id': 'm%d' % i, 'type': entries[i]['type'], 'anchor': list(spans[i])})
        if entries[i].get('project'):
            project.append('m%d' % i)
    for h, roles in by_head.items():
        for role, a in roles:
            if not add(['m%d' % h, role, 'm%d' % a], 'role:' + role, a, h):
                return None, False
        for predicate, literal in entries[h].get('literals', []):
            if not add(['m%d' % h, predicate, {'literal': literal}], 'literal:' + predicate, None, h):
                return None, False
    for i, p in enumerate(mentions):
        if p[0] == 'value' and not add(['m%d' % i, 'value', {'copy': list(spans[i])}], 'value', i, None):
            return None, False
    graph = {'nodes': nodes, 'edges': edges, 'edge_spans': evidence, 'project': project}
    try:
        native._check(graph, text)
    except ValueError:
        return None, False
    return graph, tied


def _name(graph):
    """A cheap identity for a reading. Node ids follow mention order, so no search is needed."""
    return key({'nodes': graph['nodes'], 'project': graph['project'],
                'edges': sorted(key([e, s]) for e, s in zip(graph['edges'], graph['edge_spans']))})


KEPT = 5


def _shown(ranked, pick, keep=KEPT):
    """The readings kept for the report, always including the chosen one, and its index there."""
    shown = list(ranked[:keep])
    if not any(r is pick for r in shown):
        shown = shown[:keep - 1] + [pick]
    return shown, next(i for i, r in enumerate(shown) if r is pick)


def read(text, model):
    """Read one text. Returns the chosen reading, its rivals and every count used."""
    if model.get('schema') != SCHEMA:
        raise ValueError('unsupported reader model')
    scorer = _Scorer(model)
    best, complete = {}, True
    tilings, cut_between_equals = _tilings(text, model, scorer)
    for tiling_score, pieces in tilings:
        for reading in _readings(text, model, scorer, tiling_score, pieces):
            if 'incomplete' in reading:
                complete = False
                continue
            name = _name(reading['graph'])
            if name not in best or reading['score'] > best[name]['score']:
                best[name] = reading
    ranked = sorted(best.values(), key=lambda r: (-r['score'], _name(r['graph'])))
    needed = math.log(model['policy']['margin_ratio'])
    result = {'text': text, 'readings': ranked[:KEPT], 'required_margin': needed, 'graphs': [], 'margin': None,
              'unseen_lead': None, 'cut_between_equals': cut_between_equals}
    if not complete:
        result.update(status='hold', reason='search bound reached')
    elif not ranked:
        result.update(status='unresolved', reason='the text cannot be cut into known pieces')
    else:
        # Only a reading whose every piece was seen in training can be chosen. It must
        # lead the next such reading clearly, and no unseen-piece reading may lead it clearly.
        seen = [r for r in ranked if r['supported']]
        unseen = [r for r in ranked if not r['supported']]
        if not seen:
            result.update(status='ambiguous', reason='every reading uses something never seen in training')
        else:
            margin = seen[0]['score'] - seen[1]['score'] if len(seen) > 1 else None
            behind = unseen[0]['score'] - seen[0]['score'] if unseen else None
            result.update(margin=margin, unseen_lead=behind)
            if margin is not None and margin < needed:
                result.update(status='ambiguous', reason='equal scores for two readings' if margin < 1e-9
                              else 'two readings are too close')
            elif seen[0].get('tied_evidence'):
                result.update(status='ambiguous', reason='two equally common ways to ground a fact in the text')
            elif behind is not None and behind >= needed:
                result.update(status='ambiguous', reason='a reading with an unseen piece scores clearly higher')
            elif cut_between_equals and len(ranked) < 2:
                result.update(status='hold', reason='the search dropped a candidate that scored the same as one it kept')
            else:
                if margin is None:
                    why = 'the only reading whose every piece was seen in training'
                else:
                    why = 'leads the next fully seen reading by %.2f, required %.2f' % (margin, needed)
                if behind is not None and behind > 0:
                    why += '; a reading with an unseen piece scores %.2f higher, below the %.2f that would block' % (behind, needed)
                shown, at = _shown(ranked, seen[0])
                result.update(status='complete', reason=why, graphs=[seen[0]['graph']], readings=shown, chosen=at)
    if result['status'] != 'complete':
        result['graphs'] = [r['graph'] for r in ranked[:KEPT]] if result['status'] == 'ambiguous' else []
    return result
